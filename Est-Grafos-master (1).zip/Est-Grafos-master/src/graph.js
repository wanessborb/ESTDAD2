class Graph {
  constructor() {
    this.vertices = {};
  }

  // Adiciona um vértice ao grafo
  addVertex(vertex) {
    this.vertices[vertex] = [];
  }

  // Adiciona uma aresta entre dois vértices no grafo
  addEdge(vertex1, vertex2) {
    if (this.vertices.hasOwnProperty(vertex1) && this.vertices.hasOwnProperty(vertex2)) {
      // Adiciona o vértice2 à lista de adjacência do vértice1
      this.vertices[vertex1].push(vertex2);
      // Adiciona o vértice1 à lista de adjacência do vértice2
      this.vertices[vertex2].push(vertex1);
    }
  }

  // Conta o número de loops (arestas que conectam um vértice a ele mesmo) no grafo
  countLoops() {
    let count = 0;
    for (const vertex in this.vertices) {
      if (this.vertices[vertex].includes(vertex)) {
        count++;
      }
    }
    return count;
  }




  // // Conta o número de arestas múltiplas (múltiplas arestas entre os mesmos dois vértices)
  // countMultipleEdges() {
  //   let count = 0;
  //   for (const [vertex, edges] of this.vertices) {
  //     const occurrences = {};
  //     for (const edge of edges) {
  //       occurrences[edge] = (occurrences[edge] || 0) + 1;
  //     }
  //     for (const countOccurrences of Object.values(occurrences)) {
  //       if (countOccurrences > 1) {
  //         count++;
  //       }
  //     }
  //   }
  //   return count;
  // }

  
  // Conta o número de arestas múltiplas no grafo
   countMultipleEdges() {
    let count = 0;

    // Verifica se a lista de adjacência existe
    if (this.vertices) {
      // Percorre cada lista de adjacência
      for (const vertices of Object.values(this.vertices)) {
        const edgeSet = new Set(vertices);

        // Se o tamanho do conjunto de vértices for menor que o tamanho da lista de adjacência,
        // indica a presença de arestas múltiplas
        if (edgeSet.size < vertices.length) {
          count += vertices.length - edgeSet.size;
        }
      }
    }

    return count;
  }

  
  isComplete() {
  const vertices = Object.keys(this.vertices);
  const totalVertices = vertices.length;

  for (let i = 0; i < totalVertices; i++) {
    const vertexA = vertices[i];
    for (let j = i + 1; j < totalVertices; j++) {
      const vertexB = vertices[j];
      if (!this.vertices[vertexA].includes(vertexB) && vertexA !== vertexB) {
        return false;
      }
    }
  }

  return true;
}


  // Obtém o grau de um vértice específico (número de arestas que o conectam a outros vértices)
  getDegree(vertex) {
    if (this.vertices.hasOwnProperty(vertex)) {
      return this.vertices[vertex].length;
    }
    return 0;
  }


  findPath(startVertex, endVertex, visited = []) {
    if (!this.vertices[startVertex]) {
      return null; // Não há caminho partindo do vértice inicial
    }
  
    visited.push(startVertex);
  
    if (startVertex === endVertex) {
      return visited; // Caminho encontrado
    }
  
    const edges = this.vertices[startVertex];
  
    for (const edge of edges) {
      if (!visited.includes(edge)) {
        const path = this.findPath(edge, endVertex, visited.slice());
        if (path !== null && path.length > 0 && path[path.length - 1] === endVertex) {
          return path; // Caminho encontrado
        }
      }
    }
  
    return null; // Nenhum caminho válido encontrado
  }
  

  // Conta o número total de arestas no grafo
  countTotalEdges() {
    let count = 0;
    for (const vertex in this.vertices) {
      // Conta o número de arestas do vértice atual
      count += this.vertices[vertex].length;
    }
    return count / 2; // Divide por 2, pois cada aresta é contada duas vezes (uma para cada vértice)
  }
}

module.exports = Graph;
