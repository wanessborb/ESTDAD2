const Graph = require('../src/graph');

describe('Graph', () => {
  let graph;

  beforeEach(() => {
    graph = new Graph();
  });

  test('Adicionar vértice', () => {
    // Adiciona três vértices ao grafo
    graph.addVertex('A');
    graph.addVertex('B');
    graph.addVertex('C');

    // Verifica se o número de vértices é igual a 3
    expect(Object.keys(graph.vertices).length).toBe(3);
    // Verifica se os vértices foram adicionados corretamente ao objeto de vértices
    expect(graph.vertices.hasOwnProperty('A')).toBe(true);
    expect(graph.vertices.hasOwnProperty('B')).toBe(true);
    expect(graph.vertices.hasOwnProperty('C')).toBe(true);
  });

  test('Adicionar aresta', () => {
    // Adiciona três vértices ao grafo
    graph.addVertex('A');
    graph.addVertex('B');
    graph.addVertex('C');

    // Adiciona duas arestas: A-B e B-C
    graph.addEdge('A', 'B');
    graph.addEdge('B', 'C');

    // Verifica se as arestas foram adicionadas corretamente aos vértices correspondentes
    expect(graph.vertices['A']).toContain('B');
    expect(graph.vertices['B']).toContain('A', 'C');
    expect(graph.vertices['C']).toContain('B');
  });

  test('Contar laços', () => {
    // Adiciona três vértices ao grafo
    graph.addVertex('A');
    graph.addVertex('B');
    graph.addVertex('C');

    // Adiciona duas arestas de laço: A-A e B-B
    graph.addEdge('A', 'A');
    graph.addEdge('B', 'B');

    // Verifica se a contagem de laços está correta (2 laços)
    expect(graph.countLoops()).toBe(2);
  });

  test('Contar arestas múltiplas', () => {
    // Adiciona três vértices ao grafo
    graph.addVertex('A');
    graph.addVertex('B');
    graph.addVertex('C');

    // Adiciona várias arestas múltiplas: A-B, B-C, C-D, D-A, D-A
    graph.addEdge('A', 'B');
    graph.addEdge('B', 'C');
    graph.addEdge('C', 'D');
    graph.addEdge('D', 'A');
    graph.addEdge('D', 'A');

    // Verifica se a contagem de arestas múltiplas está correta (4 arestas múltiplas)
    expect(graph.countMultipleEdges()).toBe(4);
  });


// Adicionamos três vértices ao grafo: A, B e C.
// A-B (uma vez)
// B-C (uma vez)
// C-D (uma vez)
// D-A (duas vezes)
// Ao adicionar as arestas D-A duas vezes, temos duas arestas múltiplas. Portanto, a contagem correta de arestas múltiplas é 4 no total.
// O método countMultipleEdges() percorre as listas de adjacência de cada vértice e conta quantas vezes uma mesma aresta aparece. No caso desse teste, a função deve identificar que a aresta D-A aparece duas vezes, resultando em 4 arestas múltiplas no total.




  test('Verificar se o grafo é completo', () => {
    // Adiciona quatro vértices ao grafo
    graph.addVertex('A');
    graph.addVertex('B');
    graph.addVertex('C');
    graph.addVertex('D');

    // Adiciona as arestas necessárias para formar um grafo completo
    graph.addEdge('A', 'B');
    graph.addEdge('A', 'C');
    graph.addEdge('A', 'D');
    graph.addEdge('B', 'C');
    graph.addEdge('B', 'D');
    graph.addEdge('C', 'D');

    // Verifica se o grafo é completo (espera-se true)
    expect(graph.isComplete()).toBe(true);

  });

  test('Obter grau de um vértice específico', () => {
    // Adiciona três vértices ao grafo
    graph.addVertex('A');
    graph.addVertex('B');
    graph.addVertex('C');

    // Adiciona as arestas necessárias
    graph.addEdge('A', 'B');
    graph.addEdge('A', 'C');
    graph.addEdge('B', 'C');

    // Verifica o grau de cada vértice (espera-se grau 2 para cada vértice)
    expect(graph.getDegree('A')).toBe(2);
    expect(graph.getDegree('B')).toBe(2);
    expect(graph.getDegree('C')).toBe(2);
  });

  test('Encontrar caminho entre dois vértices', () => {
    // Adiciona cinco vértices ao grafo
    graph.addVertex('A');
    graph.addVertex('B');
    graph.addVertex('C');
    graph.addVertex('D');
    graph.addVertex('E');

    // Adiciona as arestas necessárias para formar um caminho entre todos os vértices
    graph.addEdge('A', 'B');
    graph.addEdge('B', 'C');
    graph.addEdge('C', 'D');
    graph.addEdge('D', 'E');

    // Verifica se o caminho entre dois vértices está correto
    expect(graph.findPath('A', 'E')).toEqual(['A', 'B', 'C', 'D', 'E']);
    expect(graph.findPath('B', 'D')).toEqual(['B', 'C', 'D']);
  });
});
