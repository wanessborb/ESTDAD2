## Description
This is a boilerplate of a JavaScript project with jest support.

## Main commands
- `npm install` to install dependences
- `npm run test` to run tests
- `npm run test-coverage` to run tests with coverage report

## References
- [Jest - Delightful JavaScript Testing](https://jestjs.io/)