/**
 * This method creates a new tree returning the root Node. 
 * You can use a single or an array of elements.
 * 
 * @param {number|number[]} element 
 * @returns {object} tree - tree object
 */
function createTree(element) {
  if (!Array.isArray(element)) {
    element = [element];
  }

  const tree = {
    value: element[0],
    left: undefined,
    right: undefined,
  };

  for (let i = 1; i < element.length; i++) {
    insert(tree, element[i]);
  }

  return tree;
}
/**
 * Calculates the degree of a single Node
 * 
 * @param {object} tree
 * @param {number} value
 * @returns {number} degree - degree value
 */
function degree(tree, value) { 
  if (tree === undefined) {
    return undefined;
  }

  const node = getElement(tree, value);
  if (node === undefined) {
    return undefined;
  }

  let degree = 0;
  if (node.left !== undefined && node.left !== null) {
    degree++;
  }
  if (node.right !== undefined && node.right !== null) {
    degree++;
  }

  return degree;
}


/**
 * Given a root node, inserts an element. Duplicated elements are now allowed.
 * 
 * @param {object} tree
 * @param {number} value
 */
function insert(tree, value) {
  if (!tree) {
    return {
      value: value,
      left: undefined,
      right: undefined,
    };
  }

  if (value < tree.value) {
    tree.left = insert(tree.left, value);
  } else if (value > tree.value) {
    tree.right = insert(tree.right, value);
  }

  return tree;
}


/**
 * Given a root node, removes an element
 * 
 * @param {object} tree
 * @param {number} value
 * @returns {boolean} return true if a node was removed and false if not
 */


function remove(tree, value) {
  if (tree === null || tree === undefined) {
    return null;
  }

  if (value < tree.value) {
    tree.left = remove(tree.left, value);
  } else if (value > tree.value) {
    tree.right = remove(tree.right, value);
  } else {
    if (tree.left === null && tree.right === null) {
      return null;
    } else if (tree.left === null) {
      return tree.right;
    } else if (tree.right === null) {
      return tree.left;
    } else {
      const smallestRight = getSmallest(tree.right);
      if (smallestRight === null) {
        tree.value = null;
        tree.right = remove(tree.right, null);
      } else {
        tree.value = smallestRight.value;
        tree.right = remove(tree.right, smallestRight.value);
      }
    }
  }

  return tree !== null && tree !== undefined ? tree : null;
}




function getSmallest(tree) {
  if (tree === null || typeof tree !== 'object' || !tree.hasOwnProperty('left') || tree === undefined) {
    return null;
  }

  let current = tree;
  while (current !== null) {
    if (current.left === null) {
      break;
    }
    current = current.left;
  }
  return current;
}

/*function remove(tree, value) {
  if (tree === null)
    return false;

  let current = tree;
  let father = tree;
  let leftKid = true;

  while (current.value !== value) {
    father = current;
    if (current.value > value) {
      current = current.left;
      leftKid = true;
    } else {
      current = current.right;
      leftKid = false;
    }
    if (current === null)
      return false;
  }

  if (current.left === null && current.right === null) {
    if (current === tree)
      tree = null;
    else if (leftKid)
      father.left = null;
    else
      father.right = null;
  } else if (current.right === null) {
    if (current === tree)
      tree = current.left;
    else if (leftKid)
      father.left = current.left;
    else
      father.right = current.left;
  } else if (current.left === null) {
    if (current === tree)
      tree = current.right;
    else if (leftKid)
      father.left = current.right;
    else
      father.right = current.right;
  } else {
    let successor = successorNode(current);
    if (current === tree) {
      let aux = new Node();
      if (successor.left !== null) {
        aux.value = successor.left.value;
        aux.left = current.left;
      }
      successor.left = aux;
      tree.value = successor.value;
      tree.left = successor.left;
      tree.right = null;
      father = tree;
      current = father;
    } else {
      if (leftKid)
        father.left = successor;
      else
        father.right = successor;

      successor.left = current.left;
    }
  }
  return true;
}

function successorNode(clear) {
  let successorFather = clear;
  let successor = clear;
  let current = clear.right;

  while (current !== null) {
    successorFather = successor;
    if (successorFather.right !== null)
      successor = current;
    current = current.left;
  }
  if (successor !== clear.right) {
    successorFather.left = successor.right;
    successor.right = clear.right;
  }
  return successor;
}
*/



/**
 * Get the father node
 * 
 * @param {object} tree
 * @param {number} value
 * @returns {object} father - returns the father node element or undefined
 */
function getFather(tree, value) {
  if (!tree) {
    return undefined;
  }

  if (tree.left && tree.left.value === value) {
    return tree;
  }

  if (tree.right && tree.right.value === value) {
    return tree;
  }

  if (value < tree.value) {
    return getFather(tree.left, value);
  } else {
    return getFather(tree.right, value);
  }
}

/**
 * Get the brother node
 * 
 * @param {object} tree
 * @param {number} value
 * @returns {object} brother - returns the brother node or null
 */
function getBrother(tree, value) { 
  if (tree === null || tree.parent === null) {
    return null;
  }

  const parentNode = getFather(tree, value); // Fix: Changed "node.parent" to "getFather(tree, value)"
  if (parentNode.left !== null && parentNode.left.value === value) {
    return parentNode.right !== null ? parentNode.right : null;
  } else {
    return parentNode.left !== null ? parentNode.left : null;
  }
}

/**
 * Find and return a Node by element
 * 
 * @param {object} tree
 * @param {number} value
 * @returns {object} element - return the Node that contains the element or null
 */
function getElement(tree, value) { 
  if (tree === undefined) {
    return undefined;
  }

  if (tree.value === value) {
    return tree;
  } else if (value < tree.value) {
    return getElement(tree.left, value);
  } else {
    return getElement(tree.right, value);
  }
}

/**
 * Calculate the tree depth
 * 
 * @param {object} tree
 * @returns {number} depth - tree depth
 *
function calculateTreeDepth(tree) { 
  if(!tree){
    return 0;
  }

  const leftDepth = calculateTreeDepth(tree.left);
  const rightDepth = calculateTreeDepth(tree.right);
  
  return Math.max(leftDepth, rightDepth) + 1;
}*/

    
function calculateTreeDepth(tree) {
  if (tree === undefined) {
    return 0;
  }

  let depth = 0;
  let left = tree.left;
  let right = tree.right;

  if (left !== undefined) {
    let n = calculateTreeDepth(tree.left);
    depth = depth > n ? depth : n;
  }

  if (right !== undefined) {
    let n = calculateTreeDepth(tree.right);
    depth = depth > n ? depth : n;
  }

  return (right === undefined) && (left === undefined) ? 0 : ++depth;
}






function calculateNodeLevel(tree, value, level = 0) {
  if (!tree || !value) {
    return undefined;
  }

  if (tree.value === value) {
    return level;
  }

  if (value < tree.value) {
    return calculateNodeLevel(tree.left, value, level + 1);
  } else {
    return calculateNodeLevel(tree.right, value, level + 1);
  }
}




/**
 * Should use the String representation of a tree. This is an example for a
 * <pre>
 * tree:
 * root:6 (left:2 (left:1 right:4 (left:3 ))right:8 )
 * </pre>
 * 
 * @param {object} node
 * @returns {string} String representation of a tree.
 */


function toString(tree) {
  if (!tree) {
    return '';
  }

  let str = `root:${tree.value} `;
  if (tree.left || tree.right) {
    str += '(';
    if (tree.left) {
      const leftString = toString(tree.left).replace(/root:/g, '');
      if (leftString) {
        str += `left:${leftString}`;
      }
    }
    if (tree.right) {
      const rightString = toString(tree.right).replace(/root:/g, '');
      if (rightString) {
        str += `right:${rightString}`;
      }
    }
    str += ')';
  }

  return str;
}


module.exports = {
  createTree,
  degree,
  insert,
  remove,
  getFather,
  getBrother,
  getElement,
  calculateTreeDepth,
  calculateNodeLevel,
  toString
}
